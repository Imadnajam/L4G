# An example of two web services that enable to read or write into X3 via Excel

## Features

* Web services sub-program scripts
* Patchs X3